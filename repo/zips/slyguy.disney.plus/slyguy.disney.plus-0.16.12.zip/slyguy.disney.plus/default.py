from resources.lib.plugin import plugin

plugin.donor_enabled = True
plugin.dispatch()

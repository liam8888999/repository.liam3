from slyguy.dialog import ok
ok('This addon no longer works and has been deprecated. Open a github issue if you would like it to return')

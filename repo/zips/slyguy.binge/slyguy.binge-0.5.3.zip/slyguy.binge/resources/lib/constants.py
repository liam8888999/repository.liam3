HEADERS = {
    'User-Agent': 'okhttp/4.9.3',
    'Accept': '',
    'Accept-Charset': '',
}

PLAY_HEADERS = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SHIELD Android TV Build/PPR1.180610.011)',
    'Accept': '',
    'Accept-Charset': '',
}

AVATAR_URL = 'https://resources.streamotion.com.au/production/binge/profile/avatar-{avatar_id:02d}.png?imwidth=400'
LICENSE_URL = 'https://drm.streamotion.com.au/licenseServer/widevine/v1/streamotion/license'
LIVE_DATA_URL = 'https://i.mjh.nz/Binge/app.json'
EPG_URL = 'https://i.mjh.nz/Binge/epg.xml.gz'
CLIENT_ID = 'QQdtPlVtx1h9BkO09BDM2OrFi5vTPCty'
UDID = 'bc1e95db-723d-48fc-8012-effa322bdbc8'
CODE_URL = 'binge.com.au/connect'

FORMAT_HLS_TS = 'hls-ts'
FORMAT_DASH = 'dash'
FORMAT_DRM_DASH = 'drm-dash'
FORMAT_HLS_FMP4 = 'hls-fmp4'
CDN_AKAMAI = 'AKAMAI'
CDN_CLOUDFRONT = 'CLOUDFRONT'
CDN_LUMEN = 'LUMEN'
CDN_AUTO = 'AUTO'

AVAILABLE_CDNS = [CDN_AKAMAI, CDN_CLOUDFRONT, CDN_AUTO, CDN_LUMEN]
SUPPORTED_FORMATS = [FORMAT_HLS_TS, FORMAT_DASH, FORMAT_DRM_DASH, FORMAT_HLS_FMP4]

HEADERS = {
    'user-agent': 'Mozilla/5.0 (Linux; Android 8.1.0; SHIELD; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/69.0.3497.109 Mobile Safari/537.36 10play/6.2.2 UAP',
}

CONFIG_URL = 'https://vod.ten.com.au/config/androidapps-v2'

STATES = ['', 'nsw', 'vic', 'qld', 'wa', 'sa']
